import os
def clear(): return os.system('cls')

availableItem = [
    ["Surya 12", 100],
    ["Indomie", 0]
]

account = [
    ["penjual", "penjual"],
    ["pembeli", "pembeli"]
]

def hof_create_item(name, quantity):
    availableItem.append([name, quantity])
    print()
    print("[✔️  ] Barang "+ name +" Telah Ditambahkan, Dengan Banyak Stok :", quantity)
    print()
    penjualan_saya()

def read_available_item():
    for i in range(len(availableItem)):
        print("Nama Barang : ", str(availableItem[i][0]), "  \tStok Barang : " , availableItem[i][1])
    print()

def update_item():
    index = 0
    for i in range(len(availableItem)):
        index+=1
        print(index, str(availableItem[i][0]), "  \tStok Barang : " , availableItem[i][1])

    print()
    id = int(input("Masukkan Nomor Barang : "))
    name = input("Update Nama Barang : ")
    quantity = int(input("Update Banyak Stock : "))

    if  1 <= id <= len(availableItem):
        indexMinusOne = id - 1

        print()
        print("[✔️  ] Barang "+ name +" Telah Diupdate, Dengan Banyak Stok Menjadi :", quantity)
        print()
        availableItem[indexMinusOne] = [name, quantity]
        penjualan_saya()

    else:
        print()
        print("[⚠️  ] Mohon Input Dengan Benar !")
        print()
        delete_available_item()

def delete_available_item():
    index = 0
    for i in range(len(availableItem)):
        index+=1
        print(index, str(availableItem[i][0]), "  \tStok Barang : " , availableItem[i][1])

    print()

    scanHapusItem = input("Masukkan Nama Barang Yang Ingin Dihapus : ")
    for x in availableItem:
        if scanHapusItem in x:
            indexBarang = availableItem.index(x)
            availableItem.pop(indexBarang)
            print()
            print("[🎉] Selamat, Anda Berhasil Menghapus", scanHapusItem)
            print()
            penjualan_saya()
            
    else:
        clear()
        print("[⚠️  ] Mohon Input Dengan Benar !")
        print()
        delete_available_item()

def penjualan_saya():
    print("# Menu Penjualan")
    print()
    print("1. Tambahkan Barang")
    print("2. Edit Barang")
    print("3. Hapus Barang")
    print("4. Kembali")
    print()

    scanOpsiPenjualan = input("Masukkan : ")
    if scanOpsiPenjualan == "1":
        clear()
        name = input("Masukkan Nama Barang : ")
        quantity = int(input("Masukkan Banyak Barang : "))
        hof_create_item(name, quantity)
    elif scanOpsiPenjualan == "2":
        clear()
        update_item()
    elif scanOpsiPenjualan == "3":
        clear()
        delete_available_item()
    elif scanOpsiPenjualan == "4":
        clear()
        akun_penjual()
    else:
        print("p")

def beli_item():
    print("Daftar Barang Yang Tersedia : ")
    print()

    index = 0
    filtered = list(filter(lambda x: x[1] >= 1, availableItem)) # Lambda Expression ni boss
    for i in range(len((filtered))):
        index+=1
        print(index, "Nama Barang : ",str(filtered[i][0]), "  \tStok Barang : " , filtered[i][1])
    print()
    scanBeliItem = input("Masukkan Nama Barang Yang Ingin Dibeli : ")
    for x in filtered:
        if scanBeliItem in x:
            indexBarang = filtered.index(x)
            jumlah = input("Tumbas Pinten ? ")
            stock = x[1] - int(jumlah)
            filtered[indexBarang][1] = stock

            print()
            print("[🎉] Selamat, Anda Berhasil Membeli Barang", scanBeliItem, "Sebanyak ", jumlah)
            print()
            akun_pembeli()
            
    else:
        clear()
        print("[⚠️  ] Mohon Input Dengan Benar !")
        print()
        beli_item()

def login():
    clear()
    print("# Login Dulu Bos")
    print()
    userName = input("Username : ")
    userPass = input("Password : ")

    for userlogin in account:
        if userlogin[0] == userName and userlogin[1] == userPass:
            if userlogin[0] == "penjual":
                clear()
                akun_penjual()
            else:
                clear()
                akun_pembeli()
    else:
        login()

def akun_penjual():
    print("# Menu Penjual")
    print()
    print("1. Info Barang")
    print("2. Penjualan Saya")
    print("3. Kembali")
    print()

    scanOpsiPenjual = input("Masukkan : ")
    if scanOpsiPenjual == "1":
        clear()
        read_available_item()
        akun_penjual()
    elif scanOpsiPenjual == "2":
        clear()
        penjualan_saya()
    elif scanOpsiPenjual == "3":
        clear()
        login()
    
def akun_pembeli():
    print("# Menu Pembeli")
    print()
    print("1. Beli Barang Bos")
    print("2. Kembali")
    print()

    scanOpsiPembeli = input("Masukkan : ")
    if scanOpsiPembeli == "1":
        clear()
        beli_item()
    elif scanOpsiPembeli == "2":
        clear()
        login()
    else:
        clear()
        akun_pembeli

# main code
login()